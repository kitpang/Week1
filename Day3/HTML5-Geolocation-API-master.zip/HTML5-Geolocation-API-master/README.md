# HTML5-Geolocation-API
This folder contain samples of HTML5 Geolocation API for classroom training
